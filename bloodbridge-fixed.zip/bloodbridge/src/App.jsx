import { useState, useEffect, useMemo, useRef } from 'react'
import {
  Droplets, AlertTriangle, Siren, Truck, Plus, Search, ArrowUpDown, Sparkles, X,
  CheckCircle2, Activity, Building2, ArrowRight, RotateCcw, Trash2, Zap, Clock,
} from 'lucide-react'

/* ---------- constants & helpers ---------- */
const DAY = 864e5
const GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
const HOSPITALS = ['City Hospital', 'Ruby Hall Clinic', 'Sassoon General Hospital', 'KEM Hospital', 'Jehangir Hospital', 'Sahyadri Hospital', 'DPU Super Speciality']
const ymd = (o = 0) => {
  const d = new Date(Date.now() + o * DAY)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}
const daysLeft = (d) => Math.round((new Date(d + 'T00:00:00') - new Date(ymd(0) + 'T00:00:00')) / DAY)
const statusOf = (d) => { const n = daysLeft(d); return n < 0 ? 'Expired' : n <= 5 ? 'Critical' : n <= 12 ? 'Expiring Soon' : 'Optimal' }
const fefoScore = (d) => Math.max(5, Math.min(100, 100 - daysLeft(d) * 4))
const fefoLabel = (s) => (s >= 75 ? 'High Priority First-Out' : s >= 45 ? 'Use Next' : 'Standard Rotation')
const nextId = (arr, p) => {
  const max = arr.reduce((n, x) => {
    const match = String(x.id).match(/-(\d+)$/)
    return match ? Math.max(n, Number(match[1])) : n
  }, 0)
  return p + (max + 1)
}
const fmtDate = (d) => new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })

const seedInv = () =>
  [
    ['B-101', 'O+', 8, 3, 'Ruby Hall Clinic'], ['B-102', 'O+', 14, 18, 'Sassoon General Hospital'],
    ['B-103', 'A+', 10, 4, 'KEM Hospital'], ['B-104', 'A+', 9, 11, 'Jehangir Hospital'],
    ['B-105', 'B+', 7, 9, 'Sahyadri Hospital'], ['B-106', 'B+', 12, 24, 'Ruby Hall Clinic'],
    ['B-107', 'O-', 4, 5, 'Sassoon General Hospital'], ['B-108', 'O-', 6, 20, 'KEM Hospital'],
    ['B-109', 'AB+', 5, 2, 'Jehangir Hospital'], ['B-110', 'AB-', 3, 15, 'Sahyadri Hospital'],
    ['B-111', 'A-', 5, 8, 'Ruby Hall Clinic'], ['B-112', 'B-', 4, 27, 'Sassoon General Hospital'],
    ['B-113', 'O+', 10, 7, 'Jehangir Hospital'], ['B-114', 'A+', 6, 22, 'Sahyadri Hospital'],
  ].map(([id, group, units, left, hospital]) => ({ id, group, units, hospital, collected: ymd(left - 35), expiry: ymd(left) }))

const seedReqs = () => [
  { id: 'R-201', hospital: 'Sassoon General Hospital', group: 'O-', units: 5, urgency: 'Critical', status: 'Pending', time: '09:12' },
  { id: 'R-202', hospital: 'KEM Hospital', group: 'A+', units: 12, urgency: 'High', status: 'Pending', time: '09:40' },
  { id: 'R-203', hospital: 'Jehangir Hospital', group: 'AB+', units: 4, urgency: 'Critical', status: 'Pending', time: '10:05' },
  { id: 'R-204', hospital: 'Sahyadri Hospital', group: 'B+', units: 6, urgency: 'Moderate', status: 'Pending', time: '10:31' },
  { id: 'R-205', hospital: 'DPU Super Speciality', group: 'O+', units: 9, urgency: 'High', status: 'Pending', time: '10:58' },
  { id: 'R-200', hospital: 'City Hospital', group: 'B+', units: 3, urgency: 'High', status: 'Dispatched', time: '08:20' },
]
const seedHubs = () => [
  { id: 'H1', name: 'Pimpri Chinchwad Blood Centre', group: 'O+', units: 30, target: 15 },
  { id: 'H2', name: 'Hadapsar Community Hub', group: 'A+', units: 22, target: 10 },
  { id: 'H3', name: 'Baner Regional Hub', group: 'O-', units: 14, target: 6 },
  { id: 'H4', name: 'Nashik Road Partner Hub', group: 'B+', units: 20, target: 8 },
  { id: 'H5', name: 'Kothrud Medical Hub', group: 'O-', units: 3, target: 12 },
  { id: 'H6', name: 'Wakad Medical Hub', group: 'B+', units: 4, target: 10 },
  { id: 'H7', name: 'Katraj Community Hub', group: 'A+', units: 5, target: 14 },
  { id: 'H8', name: 'Kharadi Medical Hub', group: 'O+', units: 6, target: 16 },
]
const seedDisp = () => [{ id: 'D-300', kind: 'Emergency', desc: '3 units B+ → City Hospital', status: 'In Transit' }]
const seedLogs = () => [{ id: 1, t: new Date().toISOString(), msg: 'System initialised — Pune regional hub online' }]

const fefoPlan = (inv, group, need) => {
  const pool = inv.filter((b) => b.group === group && b.units > 0 && daysLeft(b.expiry) >= 0)
    .sort((a, b) => a.expiry.localeCompare(b.expiry))
  const plan = []
  let rem = need
  for (const b of pool) {
    if (rem <= 0) break
    const take = Math.min(b.units, rem)
    plan.push({ batch: b, take })
    rem -= take
  }
  return { plan, short: rem }
}
const bestSource = (hubs, hub) =>
  hubs.filter((h) => h.group === hub.group && h.units - h.target > 0).sort((a, b) => b.units - b.target - (a.units - a.target))[0]

function usePersist(key, init) {
  const [v, setV] = useState(() => {
    try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : init() } catch { return init() }
  })
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(v)) } catch { /* ignore */ } }, [key, v])
  return [v, setV]
}

/* ---------- small UI pieces ---------- */
const inp = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-500/40 focus:border-red-500'
const btnP = 'inline-flex items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-red-700 active:scale-95 transition disabled:opacity-50 disabled:cursor-not-allowed'
const btnS = 'inline-flex items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 active:scale-95 transition'
const tones = {
  red: 'bg-red-50 text-red-700 ring-red-200', amber: 'bg-amber-50 text-amber-700 ring-amber-200',
  emerald: 'bg-emerald-50 text-emerald-700 ring-emerald-200', slate: 'bg-slate-100 text-slate-600 ring-slate-200',
  blue: 'bg-sky-50 text-sky-700 ring-sky-200',
}
const Badge = ({ tone = 'slate', children }) => (
  <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ${tones[tone]}`}>{children}</span>
)
const statusTone = { Expired: 'red', Critical: 'red', 'Expiring Soon': 'amber', Optimal: 'emerald' }
const urgTone = { Critical: 'red', High: 'amber', Moderate: 'blue' }

function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-900/50 p-4" onClick={onClose}>
      <div className="max-h-[90vh] w-full max-w-md overflow-y-auto rounded-2xl bg-white shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
          <h3 className="font-semibold text-slate-900">{title}</h3>
          <button onClick={onClose} aria-label="Close" className="rounded p-1 text-slate-500 hover:bg-slate-100"><X size={18} /></button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  )
}
const Field = ({ label, children }) => (
  <label className="block text-sm"><span className="mb-1 block font-medium text-slate-700">{label}</span>{children}</label>
)
const Stat = ({ icon: Icon, label, value, tone, sub }) => (
  <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
    <div className="flex items-center justify-between">
      <p className="text-sm font-medium text-slate-500">{label}</p>
      <span className={`rounded-lg p-2 ${tones[tone]}`}><Icon size={18} /></span>
    </div>
    <p className="mt-2 text-3xl font-bold text-slate-900">{value}</p>
    <p className="mt-1 text-xs text-slate-500">{sub}</p>
  </div>
)

/* ---------- app ---------- */
export default function App() {
  const [inv, setInv] = usePersist('bb1:inv', seedInv)
  const [reqs, setReqs] = usePersist('bb1:reqs', seedReqs)
  const [hubs, setHubs] = usePersist('bb1:hubs', seedHubs)
  const [disp, setDisp] = usePersist('bb1:disp', seedDisp)
  const [logs, setLogs] = usePersist('bb1:logs', seedLogs)
  const [toasts, setToasts] = useState([])

  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')
  const [sortDir, setSortDir] = useState('asc')
  const [tab, setTab] = useState('All')
  const [modal, setModal] = useState(null) // 'batch' | 'request'
  const [fulfil, setFulfil] = useState(null)
  const [flash, setFlash] = useState(false)
  const redRef = useRef(null)

  const [bf, setBf] = useState({ hospital: HOSPITALS[0], group: 'O+', units: 5, collected: ymd(0), expiry: ymd(35) })
  const [rf, setRf] = useState({ hospital: HOSPITALS[0], group: 'O+', units: 3, urgency: 'High' })

  const toast = (msg, type = 'ok') => {
    const id = Math.random()
    setToasts((t) => [...t, { id, msg, type }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3500)
  }
  const log = (msg) => setLogs((l) => [{ id: Date.now() + Math.random(), t: new Date().toISOString(), msg }, ...l].slice(0, 100))
  const act = (msg, type = 'ok') => { log(msg); toast(msg, type) }

  // log searches once typing pauses
  useEffect(() => {
    if (!search.trim()) return
    const h = setTimeout(() => log(`Inventory searched for "${search.trim()}"`), 800)
    return () => clearTimeout(h)
  }, [search])

  const stats = useMemo(() => ({
    total: inv.filter((b) => daysLeft(b.expiry) >= 0).reduce((s, b) => s + b.units, 0),
    critical: inv.filter((b) => daysLeft(b.expiry) >= 0 && daysLeft(b.expiry) <= 5).reduce((s, b) => s + b.units, 0),
    criticalBatches: inv.filter((b) => daysLeft(b.expiry) >= 0 && daysLeft(b.expiry) <= 5).length,
    pending: reqs.filter((r) => r.status === 'Pending').length,
    active: disp.filter((d) => d.status === 'In Transit').length,
  }), [inv, reqs, disp])

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase()
    return inv
      .filter((b) => !q || b.id.toLowerCase().includes(q) || b.hospital.toLowerCase().includes(q))
      .filter((b) => filter === 'all' || (filter.startsWith('g:') ? b.group === filter.slice(2) : statusOf(b.expiry) === filter.slice(2)))
      .sort((a, b) => (sortDir === 'asc' ? a.expiry.localeCompare(b.expiry) : b.expiry.localeCompare(a.expiry)))
  }, [inv, search, filter, sortDir])

  const shownReqs = reqs.filter((r) => tab === 'All' || r.status === tab)

  /* actions */
  const addBatch = () => {
    const units = Number(bf.units)
    if (!Number.isInteger(units) || units < 1) return toast('Enter a whole number of units (at least 1).', 'err')
    if (!bf.collected || !bf.expiry) return toast('Enter both collection and expiry dates.', 'err')
    if (bf.collected > ymd(0)) return toast('Collection date cannot be in the future.', 'err')
    if (bf.expiry <= bf.collected) return toast('Expiry date must be after the collection date.', 'err')
    if (daysLeft(bf.expiry) < 0) return toast('That batch has already expired.', 'err')
    const id = nextId(inv, 'B-')
    setInv((l) => [...l, { id, group: bf.group, units, hospital: bf.hospital, collected: bf.collected, expiry: bf.expiry }])
    act(`New batch ${bf.group} added (#${id}, ${units} units, ${bf.hospital})`)
    setModal(null)
  }
  const addRequest = () => {
    const units = Number(rf.units)
    if (!Number.isInteger(units) || units < 1) return toast('Enter a whole number of units (at least 1).', 'err')
    const id = nextId(reqs, 'R-')
    setReqs((l) => [{ id, ...rf, units, status: 'Pending', time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false }) }, ...l])
    act(`Emergency request #${id} raised: ${units} units ${rf.group} for ${rf.hospital} (${rf.urgency})`, 'warn')
    setModal(null)
  }
  const acceptFulfil = () => {
    const r = fulfil
    const { plan, short } = fefoPlan(inv, r.group, r.units)
    if (short > 0) return
    setInv((l) => l.map((b) => { const p = plan.find((x) => x.batch.id === b.id); return p ? { ...b, units: b.units - p.take } : b }).filter((b) => b.units > 0))
    setReqs((l) => l.map((x) => (x.id === r.id ? { ...x, status: 'Dispatched' } : x)))
    setDisp((d) => [{ id: nextId(d, 'D-'), kind: 'Emergency', desc: `${r.units} units ${r.group} → ${r.hospital}`, status: 'In Transit' }, ...d])
    act(`${plan.map((p) => `Batch #${p.batch.id} (${p.take}u)`).join(' + ')} allocated to ${r.hospital}`)
    setFulfil(null)
  }
  const transfer = (hub) => {
    const src = bestSource(hubs, hub)
    if (!src) return act(`No surplus ${hub.group} stock available for ${hub.name}`, 'err')
    const n = Math.min(src.units - src.target, hub.target - hub.units)
    setHubs((l) => l.map((h) => (h.id === src.id ? { ...h, units: h.units - n } : h.id === hub.id ? { ...h, units: h.units + n } : h)))
    setDisp((d) => [{ id: nextId(d, 'D-'), kind: 'Transfer', desc: `${n} units ${hub.group}: ${src.name} → ${hub.name}`, status: 'In Transit' }, ...d])
    act(`Transfer confirmed: ${n} units ${hub.group} moved from ${src.name} to ${hub.name}`)
  }
  const deliver = (d) => {
    setDisp((l) => l.map((x) => (x.id === d.id ? { ...x, status: 'Delivered' } : x)))
    act(`Dispatch ${d.id} delivered (${d.desc})`)
  }
  const runCheck = () => {
    const deficits = hubs.filter((h) => h.units < h.target)
    const matched = deficits.filter((h) => bestSource(hubs, h)).length
    act(`Smart check: ${stats.criticalBatches} batch(es) near expiry, ${deficits.length} deficit hub(s), ${matched} redistribution match(es) found`, 'warn')
    redRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    setFlash(true)
    setTimeout(() => setFlash(false), 2000)
  }
  const resetDemo = () => {
    setInv(seedInv()); setReqs(seedReqs()); setHubs(seedHubs()); setDisp(seedDisp())
    setSearch(''); setFilter('all'); setSortDir('asc'); setTab('All')
    setLogs([{ id: Date.now(), t: new Date().toISOString(), msg: 'Demo data reset to defaults' }])
    toast('Demo data reset.')
  }
  const clearLog = () => { setLogs([{ id: Date.now(), t: new Date().toISOString(), msg: 'Activity log cleared' }]); toast('Activity log cleared.') }

  const fp = fulfil ? fefoPlan(inv, fulfil.group, fulfil.units) : null
  const toastTone = { ok: 'bg-emerald-600', warn: 'bg-amber-600', err: 'bg-red-600' }

  return (
    <div className="min-h-screen">
      {/* header */}
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-4">
          <div className="flex items-center gap-3">
            <span className="rounded-xl bg-red-600 p-2 text-white"><Droplets size={22} /></span>
            <div>
              <h1 className="text-lg font-bold text-slate-900 sm:text-xl">BLOODBRIDGE — Emergency Blood Supply Network</h1>
              <p className="flex items-center gap-2 text-sm text-slate-500">
                <span className="relative flex h-2.5 w-2.5"><span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" /><span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" /></span>
                System Online • Regional Hub: Pune
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm font-medium text-slate-600">{new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</span>
            <button className={btnS} onClick={resetDemo}><RotateCcw size={16} />Reset demo</button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-6 px-4 py-6">
        {/* quick actions */}
        <div className="flex flex-wrap gap-3">
          <button className={btnP} onClick={() => setModal('request')}><Siren size={16} />New Emergency Request</button>
          <button className={btnS} onClick={() => setModal('batch')}><Plus size={16} />Add Inventory Batch</button>
          <button className={btnS} onClick={runCheck}><Zap size={16} className="text-amber-500" />Run Smart Redistribution Check</button>
        </div>

        {/* stats */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Stat icon={Droplets} tone="red" label="Total Blood Stock" value={stats.total} sub="units across all batches" />
          <Stat icon={AlertTriangle} tone="amber" label="Critical Expiry Risk" value={stats.critical} sub="units expiring within 5 days" />
          <Stat icon={Siren} tone="red" label="Pending Emergency Requests" value={stats.pending} sub="awaiting allocation" />
          <Stat icon={Truck} tone="emerald" label="Active Redistribution Dispatches" value={stats.active} sub="currently in transit" />
        </div>

        {/* inventory */}
        <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 p-4">
            <h2 className="font-semibold text-slate-900">FEFO Inventory & Batch Management</h2>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
                <input className={`${inp} pl-9 sm:w-56`} placeholder="Search batch ID or hospital" value={search} onChange={(e) => setSearch(e.target.value)} />
              </div>
              <select className={`${inp} w-auto`} value={filter} onChange={(e) => { setFilter(e.target.value); log(`Inventory filter set to "${e.target.selectedOptions[0].text}"`) }}>
                <option value="all">All batches</option>
                <optgroup label="Blood group">{GROUPS.map((g) => <option key={g} value={`g:${g}`}>{g}</option>)}</optgroup>
                <optgroup label="Status">{['Optimal', 'Expiring Soon', 'Critical', 'Expired'].map((s) => <option key={s} value={`s:${s}`}>{s}</option>)}</optgroup>
              </select>
              <button className={btnS} onClick={() => { const d = sortDir === 'asc' ? 'desc' : 'asc'; setSortDir(d); log(`Inventory sorted by expiry date (${d === 'asc' ? 'soonest first' : 'latest first'})`) }}>
                <ArrowUpDown size={16} />Expiry {sortDir === 'asc' ? '↑ soonest' : '↓ latest'}
              </button>
              <button className={btnP} onClick={() => setModal('batch')}><Plus size={16} />Add batch</button>
            </div>
          </div>
          {stats.criticalBatches > 0 && (
            <div className="flex items-center gap-2 border-b border-amber-200 bg-amber-50 px-4 py-2 text-sm text-amber-800">
              <Sparkles size={16} /><strong>Smart FEFO Alert:</strong> {stats.criticalBatches} batch(es) ({stats.critical} units) expire within 5 days. Allocate these first.
            </div>
          )}
          <div className="overflow-x-auto">
            <table className="w-full min-w-[860px] text-left text-sm">
              <thead className="bg-slate-50 text-slate-500">
                <tr>{['Batch ID', 'Group', 'Units', 'Hospital', 'Collected', 'Expiry', 'Status', 'FEFO Priority Score'].map((h) => <th key={h} className="px-4 py-2.5 font-medium">{h}</th>)}</tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {rows.map((b) => {
                  const s = fefoScore(b.expiry), st = statusOf(b.expiry)
                  return (
                    <tr key={b.id} className="hover:bg-slate-50">
                      <td className="px-4 py-2.5 font-medium text-slate-900">{b.id}</td>
                      <td className="px-4 py-2.5"><Badge tone="red">{b.group}</Badge></td>
                      <td className="px-4 py-2.5">{b.units}</td>
                      <td className="px-4 py-2.5">{b.hospital}</td>
                      <td className="px-4 py-2.5">{fmtDate(b.collected)}</td>
                      <td className="px-4 py-2.5">{fmtDate(b.expiry)} <span className="text-xs text-slate-400">({daysLeft(b.expiry)}d)</span></td>
                      <td className="px-4 py-2.5"><Badge tone={statusTone[st]}>{st}</Badge></td>
                      <td className="px-4 py-2.5">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-16 rounded-full bg-slate-200"><div className={`h-1.5 rounded-full ${s >= 75 ? 'bg-red-500' : s >= 45 ? 'bg-amber-500' : 'bg-emerald-500'}`} style={{ width: `${s}%` }} /></div>
                          <span className="text-xs text-slate-600">{s} · {fefoLabel(s)}</span>
                        </div>
                      </td>
                    </tr>
                  )
                })}
                {rows.length === 0 && <tr><td colSpan={8} className="px-4 py-10 text-center text-slate-500">No batches match. Clear the search or filter, or add a batch.</td></tr>}
              </tbody>
            </table>
          </div>
        </section>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* requests */}
          <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 p-4">
              <h2 className="font-semibold text-slate-900">Emergency Request Feed</h2>
              <div className="flex rounded-lg bg-slate-100 p-1 text-sm">
                {['All', 'Pending', 'Dispatched'].map((t) => (
                  <button key={t} onClick={() => { setTab(t); log(`Request feed filtered: ${t}`) }} className={`rounded-md px-3 py-1 font-medium transition ${tab === t ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'}`}>{t}</button>
                ))}
              </div>
            </div>
            <ul className="max-h-[480px] divide-y divide-slate-100 overflow-y-auto">
              {shownReqs.map((r) => (
                <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
                  <div>
                    <p className="font-medium text-slate-900">{r.hospital}</p>
                    <p className="mt-1 flex flex-wrap items-center gap-2 text-sm text-slate-500">
                      <Badge tone="red">{r.group}</Badge> {r.units} units <Badge tone={urgTone[r.urgency]}>{r.urgency}</Badge>
                      <span className="flex items-center gap-1"><Clock size={12} />{r.time}</span> <span>#{r.id}</span>
                    </p>
                  </div>
                  {r.status === 'Pending'
                    ? <button className={btnP} onClick={() => setFulfil(r)}>Fulfill Request</button>
                    : <Badge tone="emerald"><CheckCircle2 size={12} />Dispatched</Badge>}
                </li>
              ))}
              {shownReqs.length === 0 && <li className="p-10 text-center text-sm text-slate-500">No requests here. Raise one with New Emergency Request.</li>}
            </ul>
          </section>

          {/* redistribution */}
          <section ref={redRef} className={`rounded-xl border bg-white shadow-sm transition ${flash ? 'border-amber-400 ring-4 ring-amber-200' : 'border-slate-200'}`}>
            <div className="border-b border-slate-200 p-4"><h2 className="font-semibold text-slate-900">Inter-Hospital Redistribution Network</h2></div>
            <ul className="max-h-[320px] divide-y divide-slate-100 overflow-y-auto">
              {hubs.map((h) => {
                const diff = h.units - h.target, src = diff < 0 ? bestSource(hubs, h) : null
                return (
                  <li key={h.id} className="p-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <p className="flex items-center gap-2 font-medium text-slate-900"><Building2 size={16} className="text-slate-400" />{h.name}</p>
                        <p className="mt-1 flex items-center gap-2 text-sm text-slate-500"><Badge tone="red">{h.group}</Badge>{h.units} / {h.target} units
                          <Badge tone={diff >= 0 ? 'emerald' : 'amber'}>{diff >= 0 ? `Surplus +${diff}` : `Deficit ${diff}`}</Badge></p>
                        {diff < 0 && <p className="mt-1 flex items-center gap-1 text-xs text-sky-700"><Sparkles size={12} />{src ? `Suggested Allocation: ${Math.min(src.units - src.target, -diff)} units from ${src.name}` : 'No surplus source available right now'}</p>}
                      </div>
                      {diff < 0 && <button className={btnP} disabled={!src} onClick={() => transfer(h)}><ArrowRight size={16} />Trigger Redistribution</button>}
                    </div>
                  </li>
                )
              })}
            </ul>
            <div className="border-t border-slate-200 p-4">
              <h3 className="mb-2 text-sm font-semibold text-slate-700">Dispatches</h3>
              <ul className="max-h-36 space-y-2 overflow-y-auto">
                {disp.map((d) => (
                  <li key={d.id} className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-slate-700"><span className="font-medium">{d.id}</span> · {d.desc}</span>
                    {d.status === 'In Transit'
                      ? <button className={`${btnS} px-2 py-1 text-xs`} onClick={() => deliver(d)}>Mark delivered</button>
                      : <Badge tone="emerald">Delivered</Badge>}
                  </li>
                ))}
              </ul>
            </div>
          </section>
        </div>

        {/* log */}
        <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-200 p-4">
            <h2 className="flex items-center gap-2 font-semibold text-slate-900"><Activity size={18} className="text-slate-400" />Activity Log & Audit Trail</h2>
            <button className={btnS} onClick={clearLog}><Trash2 size={16} />Clear log</button>
          </div>
          <div className="max-h-72 overflow-auto">
            <table className="w-full text-left text-sm">
              <thead className="sticky top-0 bg-slate-50 text-slate-500"><tr><th className="w-44 px-4 py-2 font-medium">Time</th><th className="px-4 py-2 font-medium">Event</th></tr></thead>
              <tbody className="divide-y divide-slate-100">
                {logs.map((l) => (
                  <tr key={l.id}><td className="whitespace-nowrap px-4 py-2 text-slate-500">{new Date(l.t).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}</td><td className="px-4 py-2 text-slate-800">{l.msg}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>

      {/* modals */}
      {modal === 'batch' && (
        <Modal title="Add New Inventory Unit" onClose={() => setModal(null)}>
          <div className="space-y-3">
            <Field label="Hospital / storage site"><select className={inp} value={bf.hospital} onChange={(e) => setBf({ ...bf, hospital: e.target.value })}>{HOSPITALS.map((h) => <option key={h}>{h}</option>)}</select></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Blood group"><select className={inp} value={bf.group} onChange={(e) => setBf({ ...bf, group: e.target.value })}>{GROUPS.map((g) => <option key={g}>{g}</option>)}</select></Field>
              <Field label="Volume (units)"><input type="number" min="1" className={inp} value={bf.units} onChange={(e) => setBf({ ...bf, units: e.target.value })} /></Field>
              <Field label="Collection date"><input type="date" className={inp} value={bf.collected} onChange={(e) => setBf({ ...bf, collected: e.target.value })} /></Field>
              <Field label="Expiry date"><input type="date" className={inp} value={bf.expiry} onChange={(e) => setBf({ ...bf, expiry: e.target.value })} /></Field>
            </div>
            <div className="flex justify-end gap-2 pt-2"><button className={btnS} onClick={() => setModal(null)}>Cancel</button><button className={btnP} onClick={addBatch}>Add batch</button></div>
          </div>
        </Modal>
      )}
      {modal === 'request' && (
        <Modal title="New Emergency Request" onClose={() => setModal(null)}>
          <div className="space-y-3">
            <Field label="Requesting hospital"><select className={inp} value={rf.hospital} onChange={(e) => setRf({ ...rf, hospital: e.target.value })}>{HOSPITALS.map((h) => <option key={h}>{h}</option>)}</select></Field>
            <div className="grid grid-cols-3 gap-3">
              <Field label="Blood group"><select className={inp} value={rf.group} onChange={(e) => setRf({ ...rf, group: e.target.value })}>{GROUPS.map((g) => <option key={g}>{g}</option>)}</select></Field>
              <Field label="Units"><input type="number" min="1" className={inp} value={rf.units} onChange={(e) => setRf({ ...rf, units: e.target.value })} /></Field>
              <Field label="Urgency"><select className={inp} value={rf.urgency} onChange={(e) => setRf({ ...rf, urgency: e.target.value })}>{['Critical', 'High', 'Moderate'].map((u) => <option key={u}>{u}</option>)}</select></Field>
            </div>
            <div className="flex justify-end gap-2 pt-2"><button className={btnS} onClick={() => setModal(null)}>Cancel</button><button className={btnP} onClick={addRequest}>Raise request</button></div>
          </div>
        </Modal>
      )}
      {fulfil && fp && (
        <Modal title={`Fulfill #${fulfil.id} — ${fulfil.hospital}`} onClose={() => setFulfil(null)}>
          <p className="mb-3 text-sm text-slate-600">Needed: <strong>{fulfil.units} units {fulfil.group}</strong> ({fulfil.urgency})</p>
          {fp.plan.length === 0 ? (
            <p className="rounded-lg bg-red-50 p-3 text-sm text-red-700">No non-expired {fulfil.group} stock available. Add a batch or trigger a redistribution.</p>
          ) : (
            <ul className="space-y-2">
              {fp.plan.map((p, i) => (
                <li key={p.batch.id} className="rounded-lg border border-slate-200 p-3 text-sm">
                  {i === 0 && <div className="mb-2"><Badge tone="blue"><Sparkles size={12} />Suggested FEFO Match</Badge></div>}
                  <p className="font-medium text-slate-900">#{p.batch.id} · take {p.take} of {p.batch.units} units</p>
                  <p className="text-slate-500">Expires {fmtDate(p.batch.expiry)} ({daysLeft(p.batch.expiry)}d) · {p.batch.hospital}</p>
                </li>
              ))}
            </ul>
          )}
          {fp.short > 0 && fp.plan.length > 0 && <p className="mt-3 rounded-lg bg-amber-50 p-3 text-sm text-amber-800">Short by {fp.short} units. Add stock or run a redistribution before dispatching.</p>}
          <div className="mt-4 flex justify-end gap-2">
            <button className={btnS} onClick={() => setFulfil(null)}>Cancel</button>
            <button className={btnP} disabled={fp.short > 0} onClick={acceptFulfil}><Truck size={16} />Accept & Dispatch</button>
          </div>
        </Modal>
      )}

      {/* toasts */}
      <div className="fixed bottom-4 right-4 z-50 flex w-80 max-w-[calc(100vw-2rem)] flex-col gap-2">
        {toasts.map((t) => (
          <div key={t.id} className={`flex items-start justify-between gap-2 rounded-lg px-4 py-3 text-sm text-white shadow-lg ${toastTone[t.type]}`}>
            <span>{t.msg}</span>
            <button aria-label="Dismiss" onClick={() => setToasts((l) => l.filter((x) => x.id !== t.id))}><X size={14} /></button>
          </div>
        ))}
      </div>
    </div>
  )
}
