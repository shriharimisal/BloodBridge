# BLOODBRIDGE — Emergency Blood Supply & FEFO Redistribution

A frontend prototype built with React, Vite, Tailwind CSS, and Lucide icons. It demonstrates inventory batches, expiry-first (FEFO) allocation, emergency requests, hub redistribution, dispatch tracking, and a local activity log.

## Run locally

Requires Node.js and npm. From this directory, run:

```bash
npm install
npm run dev
```

To create a production build:

```bash
npm run build
npm run preview
```

## Important limitations

- This is a demo/prototype, not a production blood-bank management system. Data is stored in the current browser's `localStorage`; there is no backend, shared database, login, or multi-user synchronization.
- Redistribution and FEFO suggestions are deterministic rules, not AI predictions.
- Do not use the demo data or its recommendations for real clinical or blood-bank decisions. A real deployment needs validated compatibility and safety rules, access controls, auditability, and review by qualified blood-bank personnel.

Use **Reset demo** in the header to restore seed data.
